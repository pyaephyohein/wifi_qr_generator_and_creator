# WIFI QR Create and Generate with QR for Debian based
'''
pip3 install wifiqr
'''
[pipy](https://pypi.org/project/wifiqr/)